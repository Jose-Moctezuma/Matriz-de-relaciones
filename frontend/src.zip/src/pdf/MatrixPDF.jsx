import React, { forwardRef, useMemo } from "react";

const zoneAbbrev = (zkey) => {
  const k = String(zkey || "").toLowerCase();
  if (k.includes("social") && !k.includes("semi")) return "SOC";
  if (k.includes("semisocial")) return "SeS";
  if (k.includes("serv")) return "SERV";
  if (k.includes("priv")) return "PRIV";
  return "AREA";
};

const clamp = (v, a, b) => Math.max(a, Math.min(b, v));

// Función para normalizar nombres de zona
const normalizeZoneName = (zoneName) => {
  if (!zoneName) return "";
  const name = String(zoneName).trim();
  
  const lower = name.toLowerCase();
  if (lower.includes("social") && !lower.includes("semi")) return "Área Social";
  if (lower.includes("semisocial")) return "Área Semisocial";
  if (lower.includes("servicio") || lower.includes("serv")) return "Área Servicio";
  if (lower.includes("privada") || lower.includes("priv")) return "Área Privada";
  
  return name;
};

const MatrixPDF = forwardRef(function MatrixPDF(
  {
    ZONES,
    sortedRows,
    sortedCols,
    getCellValue,
    sums,
    ranks,
    STAGE_H,
    LEFT_W,
    INNER_W,
    HEADER_H,
    BORDER,
  },
  ref
) {
  const n = sortedRows.length;

  const rowsByZone = useMemo(() => {
    const m = new Map();
    for (const z of ZONES) {
      const normalizedKey = normalizeZoneName(z.key);
      m.set(normalizedKey, []);
    }
    sortedRows.forEach((r) => {
      const normalizedZone = normalizeZoneName(r.zone);
      if (!m.has(normalizedZone)) m.set(normalizedZone, []);
      m.get(normalizedZone).push(r);
    });
    return m;
  }, [ZONES, sortedRows]);

  // Mapa de colores con nombres normalizados
  const zoneColorMap = useMemo(() => {
    const m = new Map();
    
    // Mapeo directo basado en los nombres estándar
    m.set("Área Social", "#16a34a");       // Verde
    m.set("Área Semisocial", "#f97316");   // Naranja  
    m.set("Área Servicio", "#facc15");     // Amarillo
    m.set("Área Privada", "#ef4444");      // Rojo
    
    // También agregar los valores de ZONES
    for (const z of ZONES) {
      const normalizedKey = normalizeZoneName(z.key);
      if (!m.has(normalizedKey)) {
        m.set(normalizedKey, z.color);
      }
    }
    
    return m;
  }, [ZONES]);

  // Layout
  const LEGEND_H = 130;
  const bottomSafe = 18;
  const availableHForDiamondArea = STAGE_H - LEGEND_H - bottomSafe;
  const rowH = clamp(Math.floor((availableHForDiamondArea - HEADER_H) / n), 26, 46);
  const leftH = HEADER_H + n * rowH;
  const TOP_Y = 10;
  const JOIN_GAP = -6;
  const rightMargin = 12;
  const availableW = INNER_W - (LEFT_W + JOIN_GAP) - rightMargin;

  let CELL = Math.floor(rowH / Math.SQRT2);
  CELL = clamp(CELL, 14, 42);
  let gridSide = n * CELL;
  let boundingW = gridSide * Math.SQRT2;

  if (boundingW > availableW) {
    CELL = Math.floor((availableW / Math.SQRT2) / n);
    CELL = clamp(CELL, 14, 42);
    gridSide = n * CELL;
  }

  const panelBorderFix = 3;
  const desiredLeft = (LEFT_W + panelBorderFix) + JOIN_GAP;
  const desiredTop = TOP_Y + HEADER_H - Math.round(rowH * 0.55);

  const rot45 = (px, py) => {
    const x0 = px - gridSide / 2;
    const y0 = py - gridSide / 2;
    const xr = (x0 - y0) / Math.SQRT2;
    const yr = (x0 + y0) / Math.SQRT2;
    return { xr, yr };
  };

  const triPts = [
    { x: CELL, y: 0 },
    { x: gridSide, y: 0 },
    { x: gridSide, y: gridSide - CELL },
    { x: CELL, y: CELL },
  ];

  let minX = Infinity, maxX = -Infinity, minY = Infinity, maxY = -Infinity;
  for (const p of triPts) {
    const r = rot45(p.x, p.y);
    minX = Math.min(minX, r.xr);
    maxX = Math.max(maxX, r.xr);
    minY = Math.min(minY, r.yr);
    maxY = Math.max(maxY, r.yr);
  }

  const cx = desiredLeft - minX;
  const cy = desiredTop - minY;
  const bottomTip = rot45(gridSide, gridSide - CELL);
  const diamondBottomX = cx + bottomTip.xr;
  const diamondBottomY = cy + bottomTip.yr;

  const DIAG_GAP = Math.max(8, Math.round(CELL * 0.35));
  const diagStartX = diamondBottomX;
  const diagStartY = diamondBottomY + DIAG_GAP;
  const labelOffsetX = Math.round(CELL * 2.8);
  const labelOffsetY = Math.round(CELL * 0.8);

  return (
    <div ref={ref} style={{ position: "relative", width: "100%", height: `${STAGE_H}px`, background: "#fff" }}>
      {/* PANEL IZQUIERDO */}
      <div
        style={{
          position: "absolute",
          left: 0,
          top: TOP_Y,
          width: LEFT_W,
          height: leftH,
          border: BORDER,
          boxSizing: "border-box",
          background: "#fff",
        }}
      >
        <div
          style={{
            display: "grid",
            gridTemplateColumns: "52px 1fr",
            borderBottom: "2px solid #111827",
          }}
        >
          <div
            style={{
              borderRight: "2px solid #111827",
              display: "grid",
              placeItems: "center",
              fontWeight: 900,
            }}
          >
            AREA
          </div>
          <div style={{ padding: "10px 12px", fontWeight: 900 }}>
            ESPACIOS (AMBIENTES)
          </div>
        </div>

        <div style={{ display: "grid", gridTemplateColumns: "52px 1fr", height: leftH - HEADER_H }}>
          <div style={{ borderRight: "2px solid #111827" }}>
            {ZONES.map((z) => {
              const normalizedKey = normalizeZoneName(z.key);
              const items = rowsByZone.get(normalizedKey) || [];
              if (!items.length) return null;
              return (
                <div
                  key={z.key}
                  style={{
                    height: items.length * rowH,
                    background: z.color,
                    borderBottom: "2px solid #111827",
                    display: "grid",
                    placeItems: "center",
                    fontWeight: 900,
                    letterSpacing: 0.5,
                    color: "#0b1220",
                  }}
                >
                  {zoneAbbrev(z.key)}
                </div>
              );
            })}
          </div>

          <div>
            {sortedRows.map((r) => {
              const normalizedZone = normalizeZoneName(r.zone);
              return (
                <div
                  key={r.id}
                  style={{
                    height: rowH,
                    display: "flex",
                    alignItems: "center",
                    padding: "0 12px",
                    borderBottom: "1px solid #111827",
                    fontWeight: 900,
                    color: "#111827",
                    boxShadow: `inset 6px 0 0 ${zoneColorMap.get(normalizedZone) || "#111827"}`,
                  }}
                >
                  {r.name}
                </div>
              );
            })}
          </div>
        </div>
      </div>

      {/* TRIÁNGULO */}
      <div
        style={{
          position: "absolute",
          left: desiredLeft,
          top: desiredTop,
          width: Math.ceil(gridSide * Math.SQRT2),
          height: Math.ceil(gridSide * Math.SQRT2),
          overflow: "hidden",
          clipPath: "polygon(0% 0%, 100% 0%, 100% 100%)",
        }}
      >
        <div
          style={{
            position: "absolute",
            left: cx - desiredLeft,
            top: cy - desiredTop,
            width: gridSide,
            height: gridSide,
            transform: "translate(-50%, -50%) rotate(45deg)",
            transformOrigin: "center",
            display: "grid",
            gridTemplateColumns: `repeat(${n}, ${CELL}px)`,
            gridAutoRows: `${CELL}px`,
          }}
        >
          {sortedRows.map((r, i) =>
            sortedCols.map((c, j) => {
              const v = j > i ? getCellValue(r.id, c.id) : null;
              
              // NORMALIZAR las zonas antes de comparar
              const rowZone = normalizeZoneName(r.zone);
              const colZone = normalizeZoneName(c.zone);
              
              const sameZone = rowZone === colZone;
              const hasValue = (v === 2 || v === 4);
              
              // IMPORTANTE: Determinar el color de fondo
              let cellBgColor = "#ffffff";
              
              if (hasValue && sameZone) {
                cellBgColor = zoneColorMap.get(rowZone) || "#ffffff";
              }
              
              const valueColor = v === 4 ? "#d11f1f" : v === 2 ? "#b45309" : "#111827";

              return (
                <div
                  key={`${r.id}-${c.id}`}
                  style={{
                    width: CELL,
                    height: CELL,
                    boxSizing: "border-box",
                    border: "1px solid #6b7280",
                    background: cellBgColor,
                    display: "grid",
                    placeItems: "center",
                  }}
                >
                  <div style={{ 
                    transform: "rotate(-45deg)", 
                    fontWeight: 900, 
                    fontSize: 12, 
                    color: valueColor 
                  }}>
                    {v ? v : ""}
                  </div>
                </div>
              );
            })
          )}
        </div>
      </div>

      {/* SUMATORIA */}
      <div
        style={{
          position: "absolute",
          left: diagStartX,
          top: diagStartY,
          transformOrigin: "top left",
          transform: "rotate(-45deg)",
          display: "grid",
          gridTemplateColumns: `repeat(${n}, ${CELL}px)`,
          gridAutoRows: `${CELL}px`,
        }}
      >
        {Array.from({ length: n }).map((_, i) => (
          <div
            key={`sum-${i}`}
            style={{
              width: CELL,
              height: CELL,
              border: "2px solid #111827",
              background: "#ffffff",
              display: "grid",
              placeItems: "center",
            }}
          >
            <div style={{ transform: "rotate(45deg)", fontWeight: 900, fontSize: 12 }}>
              {sums[i] ?? 0}
            </div>
          </div>
        ))}
      </div>

      {/* RANGO */}
      <div
        style={{
          position: "absolute",
          left: diagStartX,
          top: diagStartY + CELL,
          transformOrigin: "top left",
          transform: "rotate(-45deg)",
          display: "grid",
          gridTemplateColumns: `repeat(${n}, ${CELL}px)`,
          gridAutoRows: `${CELL}px`,
        }}
      >
        {Array.from({ length: n }).map((_, i) => (
          <div
            key={`rk-${i}`}
            style={{
              width: CELL,
              height: CELL,
              border: "1px solid #111827",
              background: "#ffffff",
              display: "grid",
              placeItems: "center",
            }}
          >
            <div style={{ transform: "rotate(45deg)", fontWeight: 900, fontSize: 12 }}>
              {String(ranks[i] ?? "-").startsWith("R") ? ranks[i] : `R${ranks[i]}`}
            </div>
          </div>
        ))}
      </div>

      <div
        style={{
          position: "absolute",
          left: diagStartX - labelOffsetX,
          top: diagStartY + labelOffsetY,
          transform: "rotate(-45deg)",
          fontWeight: 900,
          color: "#111827",
          letterSpacing: 0.6,
          textTransform: "uppercase",
          fontSize: 11,
        }}
      >
        SUMATORIA
      </div>

      <div
        style={{
          position: "absolute",
          left: diagStartX - labelOffsetX,
          top: diagStartY + labelOffsetY + CELL,
          transform: "rotate(-45deg)",
          fontWeight: 900,
          color: "#111827",
          letterSpacing: 0.6,
          textTransform: "uppercase",
          fontSize: 11,
        }}
      >
        RANGO
      </div>
    </div>
  );
});

export default MatrixPDF;
