import React from "react";
import { Routes, Route, Navigate, useNavigate } from "react-router-dom";

import Login from "./pages/Login.jsx";
import Register from "./pages/Register.jsx";
import Dashboard from "./pages/Dashboard.jsx";
import ProjectMatrix from "./pages/ProjectMatrix.jsx";

import { getToken, clearToken } from "./api/http.js";

function RequireAuth({ children }) {
  const token = getToken();
  if (!token) return <Navigate to="/login" replace />;
  return children;
}

export default function App() {
  const navigate = useNavigate();

  const onLogout = () => {
    clearToken();
    navigate("/login", { replace: true });
  };

  return (
    <Routes>
      {/* Entrada: si hay token -> dashboard, si no -> login */}
      <Route
        path="/"
        element={<Navigate to={getToken() ? "/dashboard" : "/login"} replace />}
      />

      <Route path="/login" element={<Login />} />
      <Route path="/register" element={<Register />} />

      <Route
        path="/dashboard"
        element={
          <RequireAuth>
            <Dashboard onLogout={onLogout} />
          </RequireAuth>
        }
      />

      <Route
        path="/project/:id"
        element={
          <RequireAuth>
            <ProjectMatrix onLogout={onLogout} />
          </RequireAuth>
        }
      />

      <Route path="*" element={<Navigate to="/" replace />} />
    </Routes>
  );
}
