import { useNavigate } from "react-router-dom";

export default function Home() {
  const navigate = useNavigate();

  return (
    <div style={{ maxWidth: 900, margin: "60px auto", fontFamily: "system-ui" }}>
      <h1>Arq Apps</h1>

      <p>
        Plataforma web de aplicaciones educativas para arquitectura.
        Aquí podrás guardar tus proyectos y usar herramientas como la
        <b> Matriz de Relaciones Ponderadas</b>.
      </p>

      <div style={{ display: "flex", gap: 12, marginTop: 20 }}>
        <button onClick={() => navigate("/login")}>Iniciar sesión</button>
        <button onClick={() => navigate("/register")}>Registrarme</button>
      </div>
    </div>
  );
}
