import { useEffect, useState } from "react";
import { useNavigate } from "react-router-dom";
import api, { clearToken, getToken } from "../api/http";

export default function Dashboard() {
  const nav = useNavigate();
  const [me, setMe] = useState(null);
  const [projects, setProjects] = useState([]);
  const [selected, setSelected] = useState(null);
  const [err, setErr] = useState("");

  async function load() {
    setErr("");
    try {
const list = await api.get("/projects");
setProjects(Array.isArray(list) ? list : []);

      // si el seleccionado ya no existe, lo quitamos
      if (selected && !(data.projects || []).some(p => p.id === selected.id)) {
        setSelected(null);
      }
    } catch (e) {
      setErr(e?.message || "Error cargando dashboard");
    }
  }

useEffect(() => {
  const token = localStorage.getItem("token");
  if (!token) {
    nav("/login");
    return;
  }
  load();
  // eslint-disable-next-line react-hooks/exhaustive-deps
}, []);


  async function newProject() {
    setErr("");
    try {
      const title = window.prompt("Nombre de la matriz:", "Matriz nueva");
      if (!title) return;
      const p = await api.post("/projects", { title });
      await load();
      // abre la matriz recién creada
      if (p?.id) nav(`/project/${p.id}`);
    } catch (e) {
      setErr(e?.message || "Error creando proyecto");
    }
  }

  async function renameProject(p) {
    setErr("");
    try {
      const title = window.prompt("Nuevo nombre de la matriz:", p.title || "Matriz");
      if (!title) return;
      await api.put(`/projects/${p.id}`, { title });  // <- NUEVO endpoint
      await load();
    } catch (e) {
      setErr(e?.message || "Error renombrando");
    }
  }

  async function deleteProject(p) {
    setErr("");
    try {
      const ok = window.confirm(`¿Eliminar definitivamente "${p.title || "Matriz"}" (ID: ${p.id})?`);
      if (!ok) return;

      await api.del(`/projects/${p.id}`); // <- tu backend ya lo tiene
      setSelected(null);
      await load();
    } catch (e) {
      setErr(e?.message || "Error eliminando");
    }
  }

  function openProject(p) {
    nav(`/project/${p.id}`);
  }

  function logout() {
    localStorage.removeItem("token");
    localStorage.removeItem("user");
    nav("/login");
  }

  return (
    <div style={{ padding: 24 }}>
      <div style={{ display: "flex", justifyContent: "space-between", alignItems: "center" }}>
        <h1 style={{ fontSize: 72, margin: 0 }}>Dashboard</h1>
        <div style={{ display: "flex", gap: 12 }}>
          <button onClick={load}>Recargar</button>
          <button onClick={logout}>Cerrar sesión</button>
        </div>
      </div>

      <div style={{ marginTop: 8, opacity: 0.75 }}>
        Sesión: {me?.email || "(sin sesión)"}
      </div>

      <hr style={{ margin: "16px 0" }} />

      {err ? (
        <div style={{ background: "#ffd7d7", padding: 12, borderRadius: 10, marginBottom: 12 }}>
          {err}
        </div>
      ) : null}

      <div style={{ display: "grid", gridTemplateColumns: "1fr 1fr", gap: 18 }}>
        {/* Lista */}
        <div>
          <div style={{ display: "flex", justifyContent: "space-between", alignItems: "center" }}>
            <h2 style={{ margin: 0 }}>Mis proyectos</h2>
            <button onClick={newProject}>Nueva matriz</button>
          </div>

          <div style={{ marginTop: 12, display: "flex", flexDirection: "column", gap: 12 }}>
            {projects.length === 0 ? (
              <div style={{ opacity: 0.7 }}>No hay proyectos aún. Crea una nueva matriz.</div>
            ) : (
              projects.map(p => (
                <div
                  key={p.id}
                  onClick={() => setSelected(p)}
                  style={{
                    border: "1px solid #e5e7eb",
                    borderRadius: 14,
                    padding: 14,
                    cursor: "pointer",
                    background: selected?.id === p.id ? "#f3f4f6" : "white"
                  }}
                >
                  <div style={{ fontWeight: 800, fontSize: 20 }}>
                    {p.title || "Matriz"}
                  </div>
                  <div style={{ opacity: 0.7 }}>
                    Tipo: {p.type} · ID: {p.id}
                  </div>

                  <div style={{ marginTop: 10, display: "flex", gap: 10, flexWrap: "wrap" }}>
                    <button onClick={(e) => { e.stopPropagation(); openProject(p); }}>
                      Abrir
                    </button>

                    <button onClick={(e) => { e.stopPropagation(); renameProject(p); }}>
                      Renombrar
                    </button>

                    <button
                      onClick={(e) => { e.stopPropagation(); deleteProject(p); }}
                      style={{ background: "#ffdddd" }}
                    >
                      Eliminar
                    </button>
                  </div>
                </div>
              ))
            )}
          </div>
        </div>

        {/* Detalle */}
        <div>
          <h2 style={{ margin: 0 }}>Detalle</h2>
          <div style={{ marginTop: 8, opacity: 0.75 }}>
            Selecciona un proyecto y presiona <b>Abrir</b> para editar la matriz.
          </div>

          {selected ? (
            <div style={{ marginTop: 12, padding: 14, border: "1px solid #e5e7eb", borderRadius: 14 }}>
              <div style={{ fontWeight: 800, fontSize: 18 }}>{selected.title || "Matriz"}</div>
              <div style={{ opacity: 0.7 }}>ID: {selected.id}</div>
              <div style={{ marginTop: 12, display: "flex", gap: 10 }}>
                <button onClick={() => openProject(selected)}>Abrir</button>
                <button onClick={() => renameProject(selected)}>Renombrar</button>
                <button onClick={() => deleteProject(selected)} style={{ background: "#ffdddd" }}>
                  Eliminar
                </button>
              </div>
            </div>
          ) : null}
        </div>
      </div>
    </div>
  );
}
