// src/pages/Login.jsx
import { useState } from "react";
import { useNavigate } from "react-router-dom";
import api, { setToken } from "../api/http";

export default function Login({ onLogin }) {
  const nav = useNavigate();
  const [email, setEmail] = useState("test@correo.com");
  const [password, setPassword] = useState("123456");
  const [error, setError] = useState("");

  async function onSubmit(e) {
    e.preventDefault();
    setError("");

    try {
      const data = await api.post("/auth/login", { email, password });

      if (!data?.token) throw new Error("El backend no devolvió token");

      // 1) Guardar token
      setToken(data.token);

      // 2) Avisar a App quién es el usuario
      if (onLogin) {
        // tu backend devuelve { ok, token, user: {id,email} }
        onLogin(data.user || null);
      }

      // 3) Ir al dashboard
      nav("/dashboard");
    } catch (err) {
      setError(err.message || "Error al iniciar sesión");
    }
  }

  return (
    <div style={{ maxWidth: 420, margin: "60px auto", fontFamily: "system-ui" }}>
      <h1 style={{ fontSize: 64, margin: 0 }}>Login</h1>

      {error ? (
        <div style={{ marginTop: 16, padding: 12, background: "#fee2e2", border: "1px solid #fecaca", borderRadius: 12 }}>
          {error}
        </div>
      ) : null}

      <form onSubmit={onSubmit} style={{ marginTop: 24, display: "grid", gap: 14 }}>
        <div>
          <div style={{ marginBottom: 6 }}>Correo</div>
          <input value={email} onChange={(e) => setEmail(e.target.value)} style={input} />
        </div>

        <div>
          <div style={{ marginBottom: 6 }}>Contraseña</div>
          <input type="password" value={password} onChange={(e) => setPassword(e.target.value)} style={input} />
        </div>

        <button type="submit" style={btn}>Entrar</button>
      </form>
    </div>
  );
}

const input = {
  width: "100%",
  padding: 12,
  borderRadius: 12,
  border: "1px solid #e5e7eb",
};

const btn = {
  padding: 14,
  borderRadius: 12,
  border: "0",
  background: "#111827",
  color: "white",
  fontWeight: 800,
  cursor: "pointer",
};
