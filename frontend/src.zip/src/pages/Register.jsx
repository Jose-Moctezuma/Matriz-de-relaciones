import { useState } from "react";
import { useNavigate } from "react-router-dom";
import api from "../api/http";

export default function Register() {
  const nav = useNavigate();
  const [email, setEmail] = useState("");
  const [password, setPassword] = useState("");
  const [error, setError] = useState("");

  async function onSubmit(e) {
    e.preventDefault();
    setError("");
    try {
      await api.post("/auth/register", { email, password });
      nav("/login");
    } catch (err) {
      setError(err.message || "Error registrando usuario");
    }
  }

  return (
    <div style={{ maxWidth: 420, margin: "60px auto", fontFamily: "system-ui" }}>
      <h1 style={{ fontSize: 56, margin: 0 }}>Registro</h1>

      {error ? (
        <div style={{ marginTop: 16, padding: 12, background: "#fee2e2", border: "1px solid #fecaca", borderRadius: 12 }}>
          {error}
        </div>
      ) : null}

      <form onSubmit={onSubmit} style={{ marginTop: 24, display: "grid", gap: 14 }}>
        <input placeholder="Correo" value={email} onChange={(e) => setEmail(e.target.value)} style={input} />
        <input placeholder="Contraseña" type="password" value={password} onChange={(e) => setPassword(e.target.value)} style={input} />
        <button type="submit" style={btn}>Crear cuenta</button>
      </form>
    </div>
  );
}

const input = {
  width: "100%",
  padding: 12,
  borderRadius: 12,
  border: "1px solid #e5e7eb",
};

const btn = {
  padding: 14,
  borderRadius: 12,
  border: "0",
  background: "#111827",
  color: "white",
  fontWeight: 800,
  cursor: "pointer",
};
