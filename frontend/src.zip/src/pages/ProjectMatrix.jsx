import MatrixPDF from "../pdf/MatrixPDF";
import { exportMatrixPDF } from "../pdf/exportMatrixPDF";
import { useRef } from "react";
import { useEffect, useMemo, useState } from "react";
import { useNavigate, useParams } from "react-router-dom";
import api from "../api/http";

const ZONES = [
  { key: "Área Social", color: "#16a34a", order: 1 },
  { key: "Área Semisocial", color: "#f97316", order: 2 },
  { key: "Área Servicio", color: "#facc15", order: 3 },
  { key: "Área Privada", color: "#ef4444", order: 4 },
];

export default function ProjectMatrix() {
  const { id } = useParams();
  const projectId = Number(id);
  const nav = useNavigate();

  const [loading, setLoading] = useState(true);
  const [err, setErr] = useState("");
  const [matrix, setMatrix] = useState(null);

  // editor modal
  const [openEditor, setOpenEditor] = useState(false);
  const [editorComponents, setEditorComponents] = useState([]);

  const load = async () => {
    try {
      setErr("");
      setLoading(true);
      const data = await api.get(`/projects/${projectId}/matrix`);
      setMatrix(data);

      // components del backend ya vienen como [{zone,name}]
      const comps = Array.isArray(data?.components) ? data.components : [];
      setEditorComponents(comps.map((c) => ({ zone: c.zone, name: c.name })));
    } catch (e) {
      setErr(e?.message || "Error al cargar matriz");
    } finally {
      setLoading(false);
    }
  };

  useEffect(() => {
    load();
    // eslint-disable-next-line react-hooks/exhaustive-deps
  }, [projectId]);

  // --- helpers de vista ---
  const rows = useMemo(() => (Array.isArray(matrix?.rows) ? matrix.rows : []), [matrix]);
  const cols = useMemo(() => (Array.isArray(matrix?.cols) ? matrix.cols : []), [matrix]);
  const cells = useMemo(() => (Array.isArray(matrix?.cells) ? matrix.cells : []), [matrix]);

const zoneOrderMap = useMemo(() => {
  const m = new Map();
  for (const z of ZONES) m.set(z.key, z.order);
  return m;
}, []);


const sortedRows = useMemo(() => {
  const zo = (zone) => zoneOrderMap.get(zone) ?? 999;
  return [...rows].sort((a, b) => {
    const za = zo(a.zone);
    const zb = zo(b.zone);
    if (za !== zb) return za - zb;                 // 1) por zona
    return (a.order ?? 0) - (b.order ?? 0);        // 2) dentro de zona por order
  });
}, [rows, zoneOrderMap]);

const sortedCols = useMemo(() => {
  const zo = (zone) => zoneOrderMap.get(zone) ?? 999;
  return [...cols].sort((a, b) => {
    const za = zo(a.zone);
    const zb = zo(b.zone);
    if (za !== zb) return za - zb;
    return (a.order ?? 0) - (b.order ?? 0);
  });
}, [cols, zoneOrderMap]);


  const cellMap = useMemo(() => {
    const m = new Map();
    for (const c of cells) {
      const a = Number(c.row_axis_id);
      const b = Number(c.col_axis_id);
      const v = Number(c.value ?? 0);

      // guardo ambas direcciones SOLO para lectura (no duplica BD)
      m.set(`${a}-${b}`, v);
      m.set(`${b}-${a}`, v);
    }
    return m;
  }, [cells]);

const reportRef = useRef(null);
// ====== PDF layout constants (antes estaban dentro del bloque grande del PDF) ======
const STAGE_H = 760;          // alto del “lienzo” del PDF (ajustable)
const LEFT_W = 360;           // ancho panel izquierdo
const INNER_W = 1120;         // ancho total del contenido (lienzo)
const HEADER_H = 64;          // alto header del panel izq

const BORDER = "3px solid #111827"; // borde panel izq (el clásico negro)

const exportPDF = async () => {
  await exportMatrixPDF(reportRef, `matriz-relaciones-proyecto-${projectId}.pdf`);
};



  const getCellValue = (a, b) => Number(cellMap.get(`${a}-${b}`) ?? 0);

  // ✅ Sumatoria por componente (fila+columna) usando índices (orden),
  // porque rows y cols pueden tener IDs diferentes.
  const sumsByIndex = useMemo(() => {
    const n = Math.min(sortedRows.length, sortedCols.length);
    const sums = Array(n).fill(0);

    for (let i = 0; i < n; i++) {
      for (let j = i + 1; j < n; j++) {
        const rowId = Number(sortedRows[i].id);
        const colId = Number(sortedCols[j].id);
        const v = getCellValue(rowId, colId);

        sums[i] += v;
        sums[j] += v;
      }
    }
    return sums;
  }, [sortedRows, sortedCols, getCellValue]);

  // ✅ Ranking por componente (mayor Σ => mejor rank)
const rankByIndex = useMemo(() => {
  const items = sortedRows.map((r, idx) => ({
    idx,
    id: Number(r.id),
    name: r.name,
    sum: Number(sumsByIndex[idx] ?? 0),
    order: Number(r.order ?? idx),
  }));

  // Orden: mayor suma primero; desempate por order y luego por nombre
  items.sort((a, b) => {
    if (b.sum !== a.sum) return b.sum - a.sum;
    if (a.order !== b.order) return a.order - b.order;
    return String(a.name).localeCompare(String(b.name));
  });

  // Dense ranking: 1,1,2,3...
  const rank = Array(sortedRows.length).fill(0);
  let currentRank = 0;
  let lastSum = null;

  for (const it of items) {
    if (lastSum === null || it.sum !== lastSum) {
      currentRank += 1;
      lastSum = it.sum;
    }
    rank[it.idx] = currentRank;
  }

  return rank;
}, [sortedRows, sumsByIndex]);

// Alias para el PDF (y para props del componente MatrixPDF)
const sums = sumsByIndex;
const ranks = rankByIndex;

// ✅ Resumen de rangos (R1, R2, ...) para el PDF
const rankingSummary = useMemo(() => {
  const map = new Map(); // rank -> [ambientes]

  sortedRows.forEach((r, idx) => {
    const rk = rankByIndex[idx];
    if (!rk) return;

    if (!map.has(rk)) map.set(rk, []);
    map.get(rk).push(r.name);
  });

  return Array.from(map.entries())
    .sort((a, b) => a[0] - b[0]) // R1, R2, R3...
    .map(([rk, names]) => ({
      rk,
      names,
    }));
}, [sortedRows, rankByIndex]);

    // ✅ SUMA POR COLUMNA (solo lo visible en el triángulo superior)
 
  
  const componentsByZone = useMemo(() => {
    const comps = Array.isArray(matrix?.components) ? matrix.components : [];
    const map = new Map();
    for (const z of ZONES) map.set(z.key, []);
    for (const c of comps) {
      if (!map.has(c.zone)) map.set(c.zone, []);
      map.get(c.zone).push(c.name);
    }
    return map;
  }, [matrix]);

  // --- acciones ---
  const saveCell = async (rowId, colId, value) => {
    try {
      setErr("");
      await api.put(`/projects/${projectId}/matrix/cell`, {
        rowId,
        colId,
        value: Number(value),
      });

      // Actualiza en memoria para que sea instantáneo
      setMatrix((prev) => {
        if (!prev) return prev;
        const nextCells = Array.isArray(prev.cells) ? [...prev.cells] : [];
        const idx = nextCells.findIndex(
          (c) => c.row_axis_id === rowId && c.col_axis_id === colId
        );
        if (idx >= 0) nextCells[idx] = { ...nextCells[idx], value: Number(value) };
        else nextCells.push({ row_axis_id: rowId, col_axis_id: colId, value: Number(value) });
        return { ...prev, cells: nextCells };
      });
    } catch (e) {
      setErr(e?.message || "No se pudo guardar relación");
    }
  };

  const onAddComponent = () => {
    setEditorComponents((prev) => [...prev, { zone: "Área Social", name: "" }]);
  };

  const onRemoveComponent = (idx) => {
    setEditorComponents((prev) => prev.filter((_, i) => i !== idx));
  };

  const onUpdateComponent = (idx, patch) => {
    setEditorComponents((prev) =>
      prev.map((c, i) => (i === idx ? { ...c, ...patch } : c))
    );
  };

  const saveAxes = async () => {
    try {
      setErr("");

      // limpia: sin vacíos y sin duplicados (zone+name)
      const cleaned = editorComponents
        .map((c) => ({
          zone: (c.zone || "").trim(),
          name: (c.name || "").trim(),
        }))
        .filter((c) => c.zone && c.name);

      const seen = new Set();
      const unique = [];
      for (const c of cleaned) {
        const k = `${c.zone}::${c.name.toLowerCase()}`;
        if (seen.has(k)) continue;
        seen.add(k);
        unique.push(c);
      }

      await api.put(`/projects/${projectId}/matrix/axes`, {
        components: unique.map((c) => ({ zone: c.zone, name: c.name })),
      });

      setOpenEditor(false);
      await load(); // recarga matriz con nuevos ejes/celdas
    } catch (e) {
      setErr(e?.message || "No se pudo guardar componentes");
    }
  };

  if (loading) {
    return (
      <div style={{ padding: 24, fontFamily: "system-ui" }}>
        Cargando matriz...
      </div>
    );
  }

  return (
    <div style={{ maxWidth: 1200, margin: "40px auto", fontFamily: "system-ui", padding: "0 16px" }}>
      <div style={{ display: "flex", alignItems: "center", justifyContent: "space-between", gap: 12 }}>
        <div>
          <h1 style={{ margin: 0, fontSize: 56, lineHeight: 1 }}>Matriz de Relaciones</h1>
          <div style={{ opacity: 0.7, marginTop: 8 }}>Proyecto ID: {projectId}</div>
        </div>

        <div style={{ display: "flex", gap: 10 }}>
          <button onClick={() => nav("/dashboard")} style={btn()}>
            Volver al dashboard
          </button>
          <button onClick={load} style={btn()}>
            Recargar
          </button>
          <button onClick={() => setOpenEditor(true)} style={btn(true)}>
            Editar componentes
          </button>
          <button onClick={exportPDF} style={btn()}>
            Exportar PDF
          </button>

        </div>
      </div>

      {err ? <div style={alert()}>{String(err)}</div> : null}

      <div style={{ display: "grid", gridTemplateColumns: "360px 1fr", gap: 16, marginTop: 18 }}>
        {/* PANEL IZQ: zonas + componentes */}
        <div style={card()}>
          <div style={{ display: "flex", gap: 8, marginBottom: 12 }}>
            <div style={pill(true)}>ZONAS</div>
            <div style={pill(false)}>COMPONENTES</div>
          </div>

          {ZONES.map((z) => (
            <div key={z.key} style={{ marginBottom: 14 }}>
              <div style={{ background: z.color, color: "white", padding: "10px 12px", borderRadius: 10, fontWeight: 700 }}>
                {z.key}
              </div>
              <div style={{ padding: 10 }}>
                {(componentsByZone.get(z.key) || []).map((name, i) => (
                  <div key={i} style={compItem()}>
                    {name}
                  </div>
                ))}
              </div>
            </div>
          ))}

          <div style={{ opacity: 0.75, marginTop: 6 }}>
            <b>Niveles de relación (PDF):</b> 0 = sin relación, 2 = deseada, 4 = necesaria.
          </div>
        </div>

        {/* PANEL DER: rombo */}
        <div style={card()}>
          <h2 style={{ marginTop: 0 }}>Relaciones (rombo)</h2>
          <div style={{ opacity: 0.7, marginBottom: 10 }}>
            Selecciona 0 / 2 / 4. Se guarda automáticamente.
          </div>

          {sortedRows.length < 2 || sortedCols.length < 2 ? (
            <div style={{ opacity: 0.75 }}>
              No hay suficientes componentes. Ve a <b>Editar componentes</b> y guarda al menos 2.
            </div>
          ) : (
            <div style={{ overflowX: "auto" }}>
              <table style={{ width: "100%", borderCollapse: "collapse" }}>
                <thead>
                  <tr>
                    <th style={th()} align="left">#</th>
                    {sortedCols.map((c) => (
                      <th key={c.id} style={th()} align="center">{c.name}</th>
                    ))}
                    <th style={th()} align="center">Σ</th>
                    <th style={th()} align="center">R</th>

                  </tr>
                </thead>

                <tbody>
                  {sortedRows.map((r, ri) => (
                    <tr key={r.id}>
                      <td style={td()}>{r.name}</td>

                      {sortedCols.map((c, ci) => {
                        // solo triángulo superior (sin diagonal)
                        if (ci <= ri) return <td key={c.id} style={td()} />;

                        const current = getCellValue(r.id, c.id);
                        return (
                          <td
                            key={c.id}
                            style={{
                              background:
                                current === 4 ? "#ff6b6b" :
                                current === 2 ? "#ffd93d" :
                                "#e0e0e0",
                              textAlign: "center",
                              fontWeight: "bold",
                              border: "1px solid #999"
                            }}
                          >
                            <select
                              value={current}
                              onChange={(e) => saveCell(r.id, c.id, Number(e.target.value))}
                              style={{
                                width: "100%",
                                background: "transparent",
                                border: "none",
                                fontWeight: "bold",
                                textAlign: "center",
                                cursor: "pointer"
                              }}
                            >
                              <option value={0}>0</option>
                              <option value={2}>2</option>
                              <option value={4}>4</option>
                            </select>
                          </td>
                        );
                      })}

                      {/* ✅ total del componente (fila + columna) */}
                      <td style={{ ...td(), textAlign: "center", fontWeight: 800 }}>
                        {sumsByIndex[ri] ?? 0}
                      </td>
                      <td
  style={{
    ...td(),
    textAlign: "center",
    fontWeight: 700,
    color: "#2563eb", // azul discreto (opcional)
  }}
>
  {`R${rankByIndex[ri] ?? "-"}`}
</td>

                    </tr>
                  ))}
                </tbody>
              </table>
            </div>
          )}
        </div>
      </div>

      {/* MODAL EDITOR */}
      {openEditor ? (
        <div style={modalOverlay()}>
          <div style={modalCard()}>
            <div style={{ display: "flex", justifyContent: "space-between", alignItems: "center", gap: 12 }}>
              <h2 style={{ margin: 0 }}>Editar Zonas y Componentes</h2>
              <button onClick={() => setOpenEditor(false)} style={btn()}>
                Cerrar
              </button>
            </div>

            <div style={{ marginTop: 16 }}>
              <div style={{ display: "flex", justifyContent: "space-between", alignItems: "center" }}>
                <h3 style={{ margin: 0 }}>Componentes</h3>
                <button onClick={onAddComponent} style={btn(true)}>
                  + Componente
                </button>
              </div>

              <div style={{ marginTop: 10, maxHeight: 420, overflow: "auto", border: "1px solid #e5e7eb", borderRadius: 12 }}>
                {editorComponents.map((c, idx) => (
                  <div key={idx} style={{ display: "grid", gridTemplateColumns: "220px 1fr 110px", gap: 10, padding: 10, borderBottom: "1px solid #eef2f7" }}>
                    <select
                      value={c.zone}
                      onChange={(e) => onUpdateComponent(idx, { zone: e.target.value })}
                      style={select(true)}
                    >
                      {ZONES.map((z) => (
                        <option key={z.key} value={z.key}>
                          {z.key}
                        </option>
                      ))}
                    </select>

                    <input
                      value={c.name}
                      onChange={(e) => onUpdateComponent(idx, { name: e.target.value })}
                      placeholder="Nombre del componente"
                      style={input()}
                    />

                    <button onClick={() => onRemoveComponent(idx)} style={dangerBtn()}>
                      Quitar
                    </button>
                  </div>
                ))}
              </div>

              <div style={{ display: "flex", justifyContent: "flex-end", gap: 10, marginTop: 14 }}>
                <button onClick={() => setOpenEditor(false)} style={btn()}>
                  Cancelar
                </button>
                <button onClick={saveAxes} style={btn(true)}>
                  Guardar y actualizar rombo
                </button>
              </div>
            </div>
          </div>
        </div>
      ) : null}

{/* ====== REPORTE PARA PDF (AUTO-RESPONSIVO A n) ====== */}
<MatrixPDF
  ref={reportRef}
  ZONES={ZONES}
  sortedRows={sortedRows}
  sortedCols={sortedCols}
  getCellValue={getCellValue}
  sums={sums}
  ranks={ranks}
  STAGE_H={STAGE_H}
  LEFT_W={LEFT_W}
  INNER_W={INNER_W}
  HEADER_H={HEADER_H}
  BORDER={BORDER}
/>


    </div>
    
  );
}

/* ---------- estilos ---------- */

function btn(primary = false) {
  return {
    border: "1px solid #e5e7eb",
    background: primary ? "#111827" : "white",
    color: primary ? "white" : "#111827",
    padding: "10px 14px",
    borderRadius: 12,
    cursor: "pointer",
    fontWeight: 600,
  };
}
function dangerBtn() {
  return {
    border: "1px solid #fecaca",
    background: "#fee2e2",
    color: "#b91c1c",
    padding: "10px 12px",
    borderRadius: 12,
    cursor: "pointer",
    fontWeight: 700,
  };
}
function card() {
  return {
    border: "1px solid rgb(238, 242, 246)",
    borderRadius: 16,
    padding: 16,
    background: "white",
  };
}
function th() {
  return {
    textAlign: "left",
    padding: "10px 8px",
    borderBottom: "1px solid #eef2f7",
    fontWeight: 800,
    whiteSpace: "nowrap",
  };
}
function td() {
  return {
    padding: "10px 8px",
    borderBottom: "1px solid #f3f4f6",
    whiteSpace: "nowrap",
  };
}
function select(compact = false) {
  return {
    border: "1px solid #e5e7eb",
    borderRadius: 12,
    padding: compact ? "10px 10px" : "8px 10px",
    background: "white",
    cursor: "pointer",
    minWidth: compact ? 0 : 58,
  };
}
function input() {
  return {
    border: "1px solid #e5e7eb",
    borderRadius: 12,
    padding: "10px 12px",
    outline: "none",
    width: "100%",
  };
}
function pill(active) {
  return {
    background: active ? "#2563eb" : "#111827",
    color: "white",
    padding: "8px 12px",
    borderRadius: 12,
    fontWeight: 800,
    letterSpacing: 0.3,
  };
}
function compItem() {
  return {
    border: "1px solid #e5e7eb",
    borderRadius: 12,
    padding: "10px 12px",
    marginBottom: 8,
    background: "white",
  };
}
function alert() {
  return {
    marginTop: 16,
    padding: 12,
    borderRadius: 14,
    background: "#fee2e2",
    border: "1px solid #fecaca",
    color: "#991b1b",
    fontWeight: 700,
  };
}
function modalOverlay() {
  return {
    position: "fixed",
    inset: 0,
    background: "rgba(0,0,0,0.35)",
    display: "flex",
    alignItems: "center",
    justifyContent: "center",
    padding: 18,
    zIndex: 9999,
  };
}
function modalCard() {
  return {
    width: "min(980px, 96vw)",
    background: "white",
    borderRadius: 18,
    padding: 18,
    border: "1px solid #e5e7eb",
  };
}
